from math import log
from collections import Counter
from tree import Tree
from operator import itemgetter

def calculate_entropy(attribute_data):
    '''Calcuate the entropy of given attribute data'''

    frequencies = Counter(attribute_data)
    probabilities = [frequencies[c]/float(len(attribute_data)) for c in frequencies]
    return sum([-p*log(p) for p in probabilities])

def hxt(attribute, dataset):
    '''Calculates H(X,T) for for an attribute X and dataset T'''
    dataset_size = len(dataset)
    attribute_vals = set(dataset[attribute])
    hxt_val = 0
    for i in attribute_vals:
        t_i = dataset[dataset[attribute] == i]
        hxt_val += (len(t_i)/float(len(dataset)))*calculate_entropy(t_i)
    return hxt_val

def calculate_information_gain(training_dataset, attribute):
    '''Calculates information gain from a particular attribute'''
    output_data = training_dataset['class']

    info_gain = calculate_entropy(output_data) - hxt(attribute,training_dataset)
    return info_gain


def get_most_common_class(dataset):
    '''return the most common class in a dataset'''
    most_common = Counter(dataset['class']).most_common(1)
    return most_common[0][0]

def id3(dataset, attributes):
    root_node = Tree()

    unique_data_classes = list(set(dataset['class']))

    if len(unique_data_classes) == 1:
        root_node.set_class_name(unique_data_classes[0])

    elif len(attributes) == 0:
        root_node.set_class_name(get_most_common_class(dataset))

    else:
        col_gains = [(col,calculate_information_gain(dataset,col)) for col in attributes]
        largest_info_gain_attr = max(col_gains, key=itemgetter(1))[0]

        root_node.set_decision_attribute(largest_info_gain_attr)
        for attr_value in set(dataset[largest_info_gain_attr]):
            child_node = Tree()
            root_node.add_child(attr_value,child_node)
            remaining_data = dataset[dataset[largest_info_gain_attr] == attr_value]
            remaining_attributes = [a for a in attributes if a != largest_info_gain_attr]
            subtree = id3(remaining_data,remaining_attributes)
            root_node.children[attr_value] = subtree
    return root_node

def classify_test_case(decision_tree, test_record):
    class_name = decision_tree.class_name
    while class_name == None:
        children = decision_tree.children
        decision_attribute = decision_tree.decision_attribute
        test_decision_attr_val = test_record[decision_attribute]
        decision_tree = children[test_decision_attr_val]
        class_name = decision_tree.class_name
    return class_name

def get_columns_under_entropy_x(data,x):
    entropies = [(c,calculate_entropy(data[c])) for c in data if c != 'class']
    return [c for c,e in entropies if e < x]
